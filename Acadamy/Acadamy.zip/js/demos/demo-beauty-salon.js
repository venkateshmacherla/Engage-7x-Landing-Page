/*
Name:           Demo Beauty Salon
Written by:     Okler Themes - (http://www.okler.net)
Theme Version:  10.2.0
*/

(function( $ ) {
	
	'use strict';

	

}).apply( this, [ jQuery ]);
