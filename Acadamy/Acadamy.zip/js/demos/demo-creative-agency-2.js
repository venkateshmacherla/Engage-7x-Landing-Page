/*
Name:           Demo Creative Agency 2
Written by:     Okler Themes - (http://www.okler.net)
Theme Version:  10.2.0
*/

(function( $ ) {
	
	'use strict';

	$(window).on('load', function () {
		setTimeout(function () {
			$('.custom-hero-bg').addClass('loaded');
		}, 500);
	
	});

}).apply( this, [ jQuery ]);
